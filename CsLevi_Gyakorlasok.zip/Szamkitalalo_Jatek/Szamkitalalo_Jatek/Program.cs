﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Szamkitalalo_Jatek
{
    class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            int i;
            int x;

            START:
                Console.WriteLine("Choose game mode!");
                Console.WriteLine("1 - You think of a number");
                Console.WriteLine("2 - The computer think of a number");

                switch (Console.ReadKey(true).KeyChar)
                {
                    case '1': goto PLAYER;
                    case '2': goto COMPUTER;
                    default:
                        throw new Exception("Invalid number!");
            }

            PLAYER:
                Console.WriteLine("Write your number between 1 - 100!");
                int myNumber = int.Parse(Console.ReadLine());
            if (myNumber < 1 || myNumber > 100)
            {
                throw new Exception("Number is not between 1 - 100");
            }

                x = 50;
                i = 0;
                int min = 0;
                int max = 100;

                while (i < 5)
                {
                    Console.WriteLine("The computer thinks of a number: {0}", x);
                    Console.WriteLine("What do you think? (Lower - l / Higher - h / Equal - e)");
                    switch (Console.ReadKey(true).KeyChar)
                    {
                        case 'l':
                            if (i == 3)
                                x = r.Next(min, x);
                            else
                            {
                                max = x;
                                x -= (max - min) / 2;
                            }
                            break;
                        case 'h':
                            if (i == 3)
                                x = r.Next(x + 1, max);
                            else
                            {
                                min = x;
                                x += (max - min) / 2;
                            }
                            break;
                        case 'e':
                            Console.WriteLine("The computer wins!");
                            goto END;
                        default:
                        throw new Exception("Invalid character!");
                    }
                    ++i;
                }

                Console.WriteLine("The computer couldn't find the number.");
            goto END;

            COMPUTER:
                int number = r.Next(100);
                i = 0;

                while(i<5)
                {
                    Console.WriteLine("\nYour tip: ");
                    x = int.Parse(Console.ReadLine());
                if (x > 100 || x < 1)
                {
                    throw new Exception("Your tip is not between 1 - 100");
                }

                    if (x<number)
                    {
                        Console.WriteLine("The number is higher!");
                    }
                    else if(x> number)
                    {
                        Console.WriteLine("The number is smaller!");
                    }
                    else
                    {
                        Console.WriteLine("You win!");
                        goto END;
                    }
                    ++i;
                }

                Console.WriteLine("\nYou lost, the number was {0}", number);
            goto END;

            END:
                Console.WriteLine("\nReady for another round? y/n");

                switch (Console.ReadKey(true).KeyChar)
                {
                    case 'y':
                        goto START;
                    case 'n':
                        break;
                    default:
                        goto END;
                }
        }
    }
}
