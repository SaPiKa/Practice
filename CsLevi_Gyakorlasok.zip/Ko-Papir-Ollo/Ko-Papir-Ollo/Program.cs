﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ko_Papir_Ollo
{
    class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            string enemy = "";
            string player = "";
            int enemyScore = 0;
            int playerScore = 0;
            bool l = true;

            do
            {
                Console.WriteLine("What do you choose? (Rock - r / Paper - p / Scissors - s)");

                //Játékos választ 
                switch (Console.ReadKey(true).KeyChar)
                {
                    case 'r':
                        player = "rock";
                        break;
                    case 'p':
                        player = "paper";
                        break;
                    case 's':
                        player = "scissors";
                        break;
                    default:
                        return;
                }

                //Ellenség véletlenszerűen választ
                switch (r.Next(0, 3))
                {
                    case 0:
                        enemy = "rock";
                        break;
                    case 1:
                        enemy = "paper";
                        break;
                    case 2:
                        enemy = "scissors";
                        break;
                    default:
                        return;
                }

                Console.WriteLine("You choose " + player + " vs. Enemy's " + enemy);
                if ((player == "rock" && enemy == "paper") ||(player == "paper" && enemy == "scissors") ||(player == "scissors" && enemy == "rock"))
                {
                    enemyScore++;
                    Console.WriteLine("Enemy wins!");
                }
                else if ((player == "paper" && enemy == "rock") || (player == "scissors" && enemy == "paper") || (player == "rock" && enemy == "scissors"))
                {
                    playerScore++;
                    Console.WriteLine("You win!");
                }
                else
                {
                    Console.WriteLine("It's a draw!");
                }

                Console.WriteLine("The score is now: " + playerScore + " | " + enemyScore);
                Console.WriteLine("Start the next match? y/n");

                if (Console.ReadKey(true).KeyChar == 'y')
                {
                    l = true;
                }
                else if (Console.ReadKey(true).KeyChar == 'n')
                {
                    l = false;
                }
                else
                {
                    throw new Exception("Invalid answer!");
                }
            } while (l);
        }
    }
}
