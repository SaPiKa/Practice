﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Szorzotabla
{
    class Program
    {
        static void Main(string[] args)
        {
            int number;
            int times;

            Console.WriteLine("Adjon meg egy számot!");
            number = int.Parse(Console.ReadLine());

            Console.WriteLine("Adja meg hányszoros szorzótáblát szeretne látni!");
            times = int.Parse(Console.ReadLine());

            for (int i = 1; i <= times; i++)
            {
                Console.WriteLine("{0} x {1} = {2}", i, number, i * number);
            }

            Console.ReadKey();
        }
    }
}
