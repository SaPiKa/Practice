﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Szamologep
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, y;
            char op = ' ';
            double value = 0;

            Console.WriteLine("Az első szám: ");
            x = int.Parse(Console.ReadLine());

            Console.WriteLine("A második szám: ");
            y = int.Parse(Console.ReadLine());

            Console.WriteLine("Az operátor (+, -, *, /): ");
            op = Convert.ToChar(Console.Read());

            switch (op)
            {
                case '+':
                    Console.WriteLine(value = x + y);
                    break;
                case '-':
                    Console.WriteLine(value = x - y);
                    break;
                case '*':
                    Console.WriteLine(value = x * y);
                    break;
                case '/':
                    Console.WriteLine(value = x / y);
                    break;
                default:
                    throw new Exception("Ismeretlen paraméter lett megadva!");
            }

            Console.ReadKey();
        }
    }
}
